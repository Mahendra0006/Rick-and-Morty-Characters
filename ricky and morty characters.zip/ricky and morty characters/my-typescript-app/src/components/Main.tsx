// src/components/Main.tsx

import React, { useEffect, useReducer, useCallback } from "react";
import Sidebar from "../common/Sidebar";
import Pagination from "../common/Pagination";
import image from "../images/logo.jpg";
import { useNavigate } from "react-router-dom";
import EpisodeService, { Episode, EpisodeResponse } from "../services/EpisodeService";
import Loader from "../common/Loader";
import { initialState, reducer } from "../reducres/mainRducer"; 
import { setLoading, fetchCharactersSuccess, setCurrentPage } from '../actions/mainAction'; 

const Main: React.FC = () => {
  const [state, dispatch] = useReducer(reducer, initialState);
  const { currentPage, characters, totalPages, loading } = state;
  const navigate = useNavigate();

  const fetchCharacters = useCallback(async (page: number): Promise<void> => {
    dispatch(setLoading(true));
    try {
      const res: EpisodeResponse = await EpisodeService.GetEpisode(`page=${page}`);
      dispatch(fetchCharactersSuccess(res?.results, res?.info?.pages));
    } catch (error) {
      console.log("Error fetching episodes", error);
    } finally {
      dispatch(setLoading(false));
    }
  }, []);

  const handlePageChange = useCallback(
    (page: number): void => {
      console.log("Page change clicked:", page);
      dispatch(setCurrentPage(page));
      fetchCharacters(page);
    },
    [fetchCharacters]
  );

  useEffect(() => {
    console.log("Current page changed:", currentPage);
    fetchCharacters(currentPage);
  }, [currentPage, fetchCharacters]);

  const handleEpisodeClick = useCallback(
    (episodeId: number): void => {
      navigate(`/episode/${episodeId}`);
    },
    [navigate]
  );

  return (
    <div className="container">
      {loading && <Loader />}
      <h2 className="" style={{ textAlign: "center" }}>Rick and Morty Characters</h2>
      <div className="row" >
        <div className="col-md-3">
          <Sidebar />
        </div>
        <div className="col-md-9">
          <div className="character-grid">
            {characters.map((character) => (
              <div
                className="character"
                key={character.id}
                onClick={() => handleEpisodeClick(character.id)}
              >
                <img
                  alt={character?.name}
                  src={character?.image ? character?.image : image}
                />
                <p style={{ marginTop: "10px", marginRight:"135px"}}>{character?.name}</p>
              </div>
            ))}
          </div>
          <Pagination
            currentPage={currentPage}
            totalPages={totalPages}
            onPageChange={handlePageChange}
          />
        </div>
      </div>
    </div>
  );
};

export default Main;
