import axios, { AxiosHeaders, AxiosInstance, AxiosResponse, InternalAxiosRequestConfig } from "axios";

// Define the instance type
const instance: AxiosInstance = axios.create({
  baseURL: `https://rickandmortyapi.com/api`,
  timeout: 50000,
  headers: {
    authorization: `${localStorage.getItem("authToken") || ''}`,
  },
});

// Define the expected response type
interface Character {
  id: number;
  name: string;
  status: string;
  species: string;
  type: string;
  gender: string;
  origin: { name: string; url: string };
  location: { name: string; url: string };
  image: string;
  episode: string[];
  url: string;
  created: string;
}

// Add a request interceptor with proper typing
instance.interceptors.request.use(function (config: InternalAxiosRequestConfig): InternalAxiosRequestConfig {
  const token = localStorage.getItem("authToken");

  if (token) {
    // Ensure config.headers exists and add the token
    if (config.headers instanceof AxiosHeaders) {
      config.headers.set("Authorization", `Bearer ${token}`);
    } else {
      // If headers is not an instance of AxiosHeaders, convert it
      config.headers = AxiosHeaders.from(config.headers);
      config.headers.set("Authorization", `Bearer ${token}`);
    }
  }

  return config;
});

// Define the response handler for Character type
const responseBody = (response: AxiosResponse<Character>): Character => response.data;

// Define the request methods with TypeScript typing
const requests = {
  get(url: string, headers?: Record<string, any>): Promise<Character> {
    return instance.get<Character>(url, { headers }).then(responseBody);
  },
  
};

// Export the requests object
export default requests;
