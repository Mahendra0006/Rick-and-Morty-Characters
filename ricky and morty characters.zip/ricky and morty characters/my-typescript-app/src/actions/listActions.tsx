export interface Episode {
    id: number;
    name: string;
    characters: string[];
  }
  
  export interface Character {
    id: number;
    name: string;
    image: string;
  }
  

  export type Action =
    | { type: "SET_LOADING"; payload: boolean }
    | { type: "FETCH_EPISODE_SUCCESS"; payload: Episode }
    | { type: "FETCH_CHARACTERS_SUCCESS"; payload: Character[] };
  

  export const setLoading = (loading: boolean): Action => ({
    type: "SET_LOADING",
    payload: loading,
  });
  
  export const fetchEpisodeSuccess = (episode: Episode): Action => ({
    type: "FETCH_EPISODE_SUCCESS",
    payload: episode,
  });
  
  export const fetchCharactersSuccess = (characters: Character[]): Action => ({
    type: "FETCH_CHARACTERS_SUCCESS",
    payload: characters,
  });
  