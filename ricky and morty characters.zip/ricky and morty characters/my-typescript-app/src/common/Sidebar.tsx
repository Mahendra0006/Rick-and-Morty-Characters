import React, { useEffect, useReducer, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import EpisodeService from "../services/EpisodeService";
import Loader from "../common/Loader";
import { initialState, reducer } from "../reducres/sidebarReducer"; 
import { fetchInit, fetchSuccess, fetchFailure } from '../actions/sidebarAction'; 

const Sidebar: React.FC = () => {
  const [state, dispatch] = useReducer(reducer, initialState);
  const { episodes, loading, error } = state;
  const navigate = useNavigate();

  useEffect(() => {
    dispatch(fetchInit()); 

    const queryString = ""; 

    EpisodeService.GetEpisode(queryString) 
      .then((res) => {
        dispatch(fetchSuccess(res.results));
      })
      .catch((error: Error) => {
        console.error("Error fetching episodes", error);
        dispatch(fetchFailure(error));
      });
  }, []);

  const handleEpisodeClick = useCallback((episodeId: number): void => {
    navigate(`/episode/${episodeId}`);
  }, [navigate]);

  return (
    <div className="sidebar">
      {loading && <Loader />}
      <h4>Episodes</h4>
      {episodes.map((episode) => (
        <button
          key={episode.id}
          className="btn btn-outline-dark episode-button"
          onClick={() => handleEpisodeClick(episode.id)}
        >
          {episode.name}
        </button>
      ))}
      {error && <div className="error">Error: {error.message}</div>}
    </div>
  );
};

export default Sidebar;
