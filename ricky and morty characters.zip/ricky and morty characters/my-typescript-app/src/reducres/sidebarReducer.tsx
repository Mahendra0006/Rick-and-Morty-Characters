import { Action } from '../actions/sidebarAction';
import { Episode } from "../services/EpisodeService";

export interface State {
  episodes: Episode[];
  loading: boolean;
  error: Error | null;
}

export const initialState: State = {
  episodes: [],
  loading: false,
  error: null,
};

export const reducer = (state: State, action: Action): State => {
  switch (action.type) {
    case "FETCH_INIT":
      return { ...state, loading: true, error: null };
    case "FETCH_SUCCESS":
      return { ...state, loading: false, episodes: action.payload };
    case "FETCH_FAILURE":
      return { ...state, loading: false, error: action.payload };
    default:
      return state;
  }
};
